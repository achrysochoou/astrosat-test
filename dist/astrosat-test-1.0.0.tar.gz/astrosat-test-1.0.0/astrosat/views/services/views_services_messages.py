from django.contrib.messages import get_messages
from django.http import HttpResponseForbidden, JsonResponse


def get_django_messages(request):
    """
    finds all pending Django messages and sticks them into a JSON array
    this in turn gets accessed by an Angular app which then uses
    JS (bootbox) to display them as pretty pop-up messages
    (see "check_msg" in "astrosat_base.js")
    :param request:
    :return:
    """
    if not request.is_ajax():
        msg = "Attempt to call service view outside of AJAX."
        return HttpResponseForbidden(msg)

    # the very act of accessing these messages pops them off the message queue;
    # Yay Django!
    messages = get_messages(request)

    data = []
    for message in messages:
        data.append({
            "text": message.message,
            "status": message.tags,
        })

    return JsonResponse(data, safe=False)
