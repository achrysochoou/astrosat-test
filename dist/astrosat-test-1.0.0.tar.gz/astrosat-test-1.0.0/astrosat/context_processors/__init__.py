from .context_processors import astrosat_cdn, astrosat_debug
