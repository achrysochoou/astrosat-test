from django.urls import reverse
from facilities.tests.test_base import FacilitiesTestCase
from facilities.views.services import *


class Test(FacilitiesTestCase):

    def test_services_get_facilities(self):
        request_url = reverse("get_facilities")
        request = self.factory.get(request_url)

        get_facilities(request)

